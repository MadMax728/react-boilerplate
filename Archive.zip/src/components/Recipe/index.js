import Recipe from './Recipe';
export default Recipe;

// import React, {Component} from 'react';
// import Recipe from './Recipe';

// class Index extends Component {

//     render() {
//         return(
//             <Recipe></Recipe>
//         );
//     }
// } 
// export default Index;