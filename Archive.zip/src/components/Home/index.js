
import React, {Component} from 'react';
import Home from './Home';

class Index extends Component {

    render() {
        return(
            <Home></Home>
        );
    }
}
export default Index;