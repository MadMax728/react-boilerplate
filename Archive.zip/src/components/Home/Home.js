import React, {Component} from 'react';

class Home extends  Component {

    componentDidMount() {

    }
    render() {
        return(
            <div>Welcome TO MaDMaX Words</div>
        );
    }
}

export default Home;