export const recipeBook = [{
        id: "111",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "112",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "113",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "114",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "115",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "116",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "117",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "118",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "119",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    },{
        id: "120",
        name: "Biryani",
        ingredients: "Rice, masale, onion etc."
    }
];