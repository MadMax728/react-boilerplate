const initialState = {
    recipeBook: {
        books: [],
        cartList: []
    }
}
export default initialState;